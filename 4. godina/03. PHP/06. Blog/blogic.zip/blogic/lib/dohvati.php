<?php
    include './posts.php';
    get_posts();

?>